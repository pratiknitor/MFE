# create mfe1 application
npx ng new mfe2
cd mfe2

# Add module federation lib
npx ng add @angular-architects/module-federation@15.0.3 --project mfe1 --port 4202 --type remote

# create new module 
npx ng generate module secondMfe

# create new component in mfe1 module
npx ng generate component second-mfe/mfe-bookings --module second-mfe