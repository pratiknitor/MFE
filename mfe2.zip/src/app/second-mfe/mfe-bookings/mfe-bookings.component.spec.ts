import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MfeBookingsComponent } from './mfe-bookings.component';

describe('MfeBookingsComponent', () => {
  let component: MfeBookingsComponent;
  let fixture: ComponentFixture<MfeBookingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MfeBookingsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MfeBookingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
