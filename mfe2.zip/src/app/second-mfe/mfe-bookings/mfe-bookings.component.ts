import { Component } from '@angular/core';

@Component({
  selector: 'app-mfe-bookings',
  templateUrl: './mfe-bookings.component.html',
  styleUrls: ['./mfe-bookings.component.css']
})
export class MfeBookingsComponent {

}
