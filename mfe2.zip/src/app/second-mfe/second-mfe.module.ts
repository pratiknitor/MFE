import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MfeBookingsComponent } from './mfe-bookings/mfe-bookings.component';
import { Route, RouterModule } from '@angular/router';

export const remoteRoutes: Route[] = [
  { path: '', component: MfeBookingsComponent },   // Add route
];

@NgModule({
  declarations: [
    MfeBookingsComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(remoteRoutes) //for child
  ]
})
export class SecondMfeModule { }
