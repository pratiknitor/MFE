# create mfe1 application
npx ng new mfe1
cd mfe1

# Add module federation lib
npx ng add @angular-architects/module-federation@15.0.3 --project mfe1 --port 4201 --type remote

# create new module 
npx ng generate module remoteMfe

# create new component in mfe1 module
npx ng generate component remote-mfe/mfe-home --module remote-mfe