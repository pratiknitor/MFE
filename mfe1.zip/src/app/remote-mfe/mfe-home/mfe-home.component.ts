import { Component } from '@angular/core';

@Component({
  selector: 'app-mfe-home',
  templateUrl: './mfe-home.component.html',
  styleUrls: ['./mfe-home.component.css']
})
export class MfeHomeComponent {

}
